# v11.2.1 — Viewport Integrity Fix

Focused corrective release for the reported viewport issues.

- Prevented InsightRail from becoming a third grid row and shrinking the Gantt stage.
- Made the Gantt canvas/header/grid a single full-height flex composition.
- Made Resource Orbit participate in the main content flow instead of anchoring to the browser viewport.
- Made Network/Pulse overlays start below the app topbar and beside the navigation rail.
- Added rail-aware overlay positioning for collapsed/expanded navigation.
- Preserved theme-aware visualization surfaces.
- Kept visualization content scrollable when content genuinely exceeds the available canvas.

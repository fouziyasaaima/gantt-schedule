import type { Project, Task, Dependency, Resource, ExplainResult, TargetResult } from "@/types/gantt";
import { notify } from "@/lib/notifications";

export interface ApiConfig {
  baseUrl: string;
}

export type Connector = { id:string; name:string; provider:string; baseUrl:string; authType:string; status:string; direction:string; config:any; lastTestedAt?:string|null; lastSyncAt?:string|null; lastError?:string|null; mappings?:ConnectorMapping[]; };
export type ConnectorMapping = { id:string; entityType:string; externalField:string; internalField:string; direction:string; transform:any; required:boolean; };

class ApiError extends Error {
  constructor(public status: number, message: string, public code?: string, public details?: unknown) { super(message); this.name="ApiError"; }
}

async function request<T>(config: ApiConfig, path: string, init?: RequestInit): Promise<T> {
  const baseUrl = config.baseUrl.replace(/\/+$/, "");
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 20_000);
  try {
    const res = await fetch(`${baseUrl}${path}`, {
      ...init,
      signal: init?.signal ?? controller.signal,
      credentials: "include",
      headers: {
        ...(init?.body !== undefined ? { "Content-Type": "application/json" } : {}),
        Accept: "application/json",
        ...(init?.headers || {}),
      },
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({ error: res.statusText }));
      const detail = body.code ? ` [${body.code}]` : "";
      const message = `${body.error || `Request failed: ${res.status}`}${detail}`;
      notify({ kind: res.status >= 500 ? "error" : "warning", title: "Action could not be completed", message, id: `api-error:${init?.method || "GET"}:${path}:${body.code || res.status}` });
      throw new ApiError(res.status, message, body.code, body);
    }
    if (res.status === 204) {
      if (init?.method && init.method !== "GET") notify({ kind: "success", title: actionLabel(init.method, path), message: "The change was saved successfully." });
      return undefined as T;
    }
    const result = await res.json() as T;
    if (init?.method && init.method !== "GET") notify({ kind: "success", title: actionLabel(init.method, path), message: "The change was saved successfully." });
    return result;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    if (error instanceof DOMException && error.name === "AbortError") {
      const message = `Schedule Intelligence API request timed out after 20 seconds.`;
      notify({ kind: "error", title: "Action timed out", message });
      throw new TypeError(`${message} ${baseUrl}${path}`);
    }
    const message = `Unable to reach Schedule Intelligence API. ${error instanceof Error ? error.message : "Network request failed."}`;
    notify({ kind: "error", title: "Connection problem", message });
    throw new TypeError(`${message} ${baseUrl}`);
  } finally {
    window.clearTimeout(timeout);
  }
}


function actionLabel(method: string, path: string) {
  const p = path.toLowerCase();
  if (method === "POST" && p.includes("dependencies")) return "Dependency created";
  if (method === "PATCH" && p.includes("dependencies")) return "Dependency updated";
  if (method === "DELETE" && p.includes("dependencies")) return "Dependency removed";
  if (method === "POST" && p.includes("simulations")) return "Forecast completed";
  if (method === "POST" && p.includes("recompute")) return "Schedule recomputed";
  if (method === "POST" && p.includes("scenarios")) return "Scenario saved";
  if (method === "POST" && p.includes("assignments")) return "Resource assignment saved";
  if (method === "DELETE" && p.includes("assignments")) return "Resource assignment removed";
  if (method === "POST" && p.includes("resources")) return "Resource created";
  if (method === "DELETE" && p.includes("resources")) return "Resource removed";
  if (method === "POST" && p.includes("tasks")) return "Task created";
  if (method === "PATCH" && p.includes("tasks")) return "Task updated";
  if (method === "DELETE" && p.includes("tasks")) return "Task deleted";
  if (method === "POST" && p.includes("projects")) return "Project created";
  return "Change completed";
}

export const connectorApi = {
  list:(c:ApiConfig)=>request<Connector[]>(c,"/v1/connectors"),
  get:(c:ApiConfig,id:string)=>request<Connector>(c,`/v1/connectors/${id}`),
  create:(c:ApiConfig,body:any)=>request<Connector>(c,"/v1/connectors",{method:"POST",body:JSON.stringify(body)}),
  update:(c:ApiConfig,id:string,body:any)=>request<Connector>(c,`/v1/connectors/${id}`,{method:"PATCH",body:JSON.stringify(body)}),
  remove:(c:ApiConfig,id:string)=>request<void>(c,`/v1/connectors/${id}`,{method:"DELETE"}),
  test:(c:ApiConfig,id:string)=>request<any>(c,`/v1/connectors/${id}/test`,{method:"POST",body:JSON.stringify({})}),
  testWrite:(c:ApiConfig,id:string,operationKey:string,body:any)=>request<any>(c,`/v1/connectors/${id}/test-write`,{method:"POST",body:JSON.stringify({operationKey,body})}),
  authorize:(c:ApiConfig,id:string)=>request<{url:string}>(c,`/v1/connectors/${id}/oauth/authorize`),
  sync:(c:ApiConfig,id:string)=>request<any>(c,`/v1/connectors/${id}/sync`,{method:"POST",body:JSON.stringify({})}),
  runs:(c:ApiConfig,id:string)=>request<any[]>(c,`/v1/connectors/${id}/sync-runs`),
  addMapping:(c:ApiConfig,id:string,body:any)=>request<ConnectorMapping>(c,`/v1/connectors/${id}/mappings`,{method:"POST",body:JSON.stringify(body)}),
  removeMapping:(c:ApiConfig,id:string,mappingId:string)=>request<void>(c,`/v1/connectors/${id}/mappings/${mappingId}`,{method:"DELETE"}),
  webhook:(c:ApiConfig,id:string)=>request<{id:string;token:string}>(c,`/v1/connectors/${id}/webhooks`,{method:"POST",body:JSON.stringify({})}),
};

export const api = {
  // Projects
  listProjects: (c: ApiConfig) => request<Project[]>(c, "/v1/projects"),
  createProject: (c: ApiConfig, body: { name: string; description?: string; startDate: string }) => request<Project>(c, "/v1/projects", { method: "POST", body: JSON.stringify(body) }),
  getProject: (c: ApiConfig, id: string) => request<Project>(c, `/v1/projects/${id}`),

  // Tasks
  listTasks: (c: ApiConfig, projectId: string) =>
    request<Task[]>(c, `/v1/projects/${projectId}/tasks`),

  createTask: (
    c: ApiConfig,
    projectId: string,
    body: {
      name: string;
      taskType?: string;
      expectedStart: string;
      expectedEnd: string;
      parentId?: string;
    }
  ) =>
    request<Task>(c, `/v1/projects/${projectId}/tasks`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  // The single mutation endpoint for every date change — drag or typed date,
  // both call this exact function with the same shape.
  updateTask: (c: ApiConfig, taskId: string, patch: Partial<Task>) =>
    request<Task>(c, `/v1/tasks/${taskId}`, {
      method: "PATCH",
      body: JSON.stringify(patch),
    }),

  deleteTask: (c: ApiConfig, taskId: string) =>
    request<void>(c, `/v1/tasks/${taskId}`, { method: "DELETE" }),

  setTarget: (c: ApiConfig, taskId: string, targetDate: string | null) =>
    request<TargetResult>(c, `/v1/tasks/${taskId}/target`, {
      method: "POST",
      body: JSON.stringify({ targetDate }),
    }),

  explainTask: (c: ApiConfig, taskId: string) =>
    request<ExplainResult>(c, `/v1/tasks/${taskId}/explain`),

  // Dependencies
  listDependencies: (c: ApiConfig, projectId: string) =>
    request<Dependency[]>(c, `/v1/projects/${projectId}/dependencies`),

  createDependency: (
    c: ApiConfig,
    projectId: string,
    body: { predecessorId: string; successorId: string; dependencyType?: string; lagDays?: number }
  ) =>
    request<{dependency: Dependency; schedule: {taskCount:number;criticalTaskCount:number;changedTaskCount:number;movedTaskCount:number;changedTasks:Array<{taskId:string;taskName:string;startShiftDays:number;finishShiftDays:number;oldSlack:number|null;slackDays:number;oldIsCritical:boolean|null;isCritical:boolean}>;computedAt:string}|null}>(c, `/v1/projects/${projectId}/dependencies`, {
      method: "POST",
      body: JSON.stringify(body),
    }),

  updateDependency: (c: ApiConfig, id: string, body: { dependencyType?: string; lagDays?: number }) =>
    request<Dependency>(c, `/v1/dependencies/${id}`, { method: "PATCH", body: JSON.stringify(body) }),
  deleteDependency: (c: ApiConfig, id: string) =>
    request<void>(c, `/v1/dependencies/${id}`, { method: "DELETE" }),

  // Resources
  listResources: (c: ApiConfig) => request<Resource[]>(c, "/v1/resources"),
  createResource: (c: ApiConfig, body: { name: string; role?: string; capacityHoursPerDay?: number }) =>
    request<Resource>(c, "/v1/resources", { method: "POST", body: JSON.stringify(body) }),
  deleteResource: (c: ApiConfig, id: string) => request<void>(c, `/v1/resources/${id}`, { method: "DELETE" }),
  assignResource: (c: ApiConfig, taskId: string, body: { resourceId: string; allocationPct?: number }) =>
    request<{ id: string; taskId: string; resourceId: string; allocationPct: number }>(c, `/v1/tasks/${taskId}/assignments`, { method: "POST", body: JSON.stringify(body) }),
  deleteAssignment: (c: ApiConfig, id: string) => request<void>(c, `/v1/assignments/${id}`, { method: "DELETE" }),
  getResourceWorkload: (c: ApiConfig, id: string) => request<{ resourceId: string; capacityHoursPerDay: number; peakAllocationPct:number; peakAllocatedHoursPerDay:number; overloaded:boolean; peakAt:string|null; assignments: Array<{assignmentId:string;taskId:string;taskName:string;start:string;end:string;allocationPct:number;allocatedHoursPerDay:number}> }>(c, `/v1/resources/${id}/workload`),
  getProjectResourceLeveling: (c: ApiConfig, projectId: string) => request<{projectId:string;resources:Array<{resourceId:string;name:string;capacityHoursPerDay:number;allocationPct:number;overloaded:boolean;assignments:Array<{taskId:string;taskName:string;allocationPct:number;start:string;end:string}>}>;overloadedCount:number}>(c, `/v1/projects/${projectId}/resources/leveling`),

  monteCarlo: (c: ApiConfig, projectId: string, body: { iterations?: number; uncertainty?: number }) =>
    request<any>(c, `/v1/projects/${projectId}/simulations/monte-carlo`, { method: "POST", body: JSON.stringify(body) }),
  scenarioImpact: (c: ApiConfig, projectId: string, body: { changes: Array<{ taskId: string; expectedStart?: string; expectedEnd?: string; durationDays?: number }> }) =>
    request<{beforeFinish:string;afterFinish:string;deltaDays:number;impactedTasks:Array<{taskId:string;startShiftDays:number;finishShiftDays:number}>;warning:string}>(c, `/v1/projects/${projectId}/scenarios/impact`, { method: "POST", body: JSON.stringify(body) }),
  // Enterprise organization/admin
  listApiKeys: (c: ApiConfig, organizationId: string) => request<any[]>(c, `/v1/organizations/${organizationId}/api-keys`),
  createApiKey: (c: ApiConfig, organizationId: string, body: {label:string;scopes:string[]}) => request<any>(c, `/v1/organizations/${organizationId}/api-keys`, {method:"POST",body:JSON.stringify(body)}),
  revokeApiKey: (c: ApiConfig, organizationId: string, keyId: string) => request<any>(c, `/v1/organizations/${organizationId}/api-keys/${keyId}`, {method:"DELETE"}),
  inviteMember: (c: ApiConfig, organizationId: string, body: {email:string;role:string}) => request<any>(c, `/v1/organizations/${organizationId}/invitations`, {method:"POST",body:JSON.stringify(body)}),
  listMembers: (c: ApiConfig, organizationId: string) => request<any[]>(c, `/v1/organizations/${organizationId}/members`),
  auditLog: (c: ApiConfig, organizationId: string) => request<any[]>(c, `/v1/organizations/${organizationId}/audit-log`),

  health: (c: ApiConfig, projectId: string) => request<any>(c, `/v1/projects/${projectId}/intelligence/health`),
  decisionBrief: (c: ApiConfig, projectId: string) => request<any>(c, `/v1/projects/${projectId}/decision/brief`),
  intelligenceSummary: (c: ApiConfig, projectId: string) => request<any>(c, `/v1/projects/${projectId}/intelligence/summary`),
  recoveryRecommendations: (c: ApiConfig, projectId: string, body: { targetDate?: string }) => request<any>(c, `/v1/projects/${projectId}/recovery/recommendations`, { method:"POST", body:JSON.stringify(body) }),
  resourceLeveling: (c: ApiConfig, projectId: string) => request<any>(c, `/v1/projects/${projectId}/resources/leveling`),
  listScenarios: (c: ApiConfig, projectId: string) => request<any[]>(c, `/v1/projects/${projectId}/scenarios`),
  saveScenario: (c: ApiConfig, projectId: string, body: any) => request<any>(c, `/v1/projects/${projectId}/scenarios`, { method:"POST", body:JSON.stringify(body) }),
  compareScenarios: (c: ApiConfig, projectId: string, body: any) => request<any>(c, `/v1/projects/${projectId}/scenarios/compare`, { method:"POST", body:JSON.stringify(body) }),
  forecastRuns: (c: ApiConfig, projectId: string) => request<any[]>(c, `/v1/projects/${projectId}/forecast-runs`),
  history: (c: ApiConfig, projectId: string) => request<any[]>(c, `/v1/projects/${projectId}/history`),
  createSnapshot: (c: ApiConfig, projectId: string, label: string) => request<any>(c, `/v1/projects/${projectId}/history/snapshots`, {method:"POST", body:JSON.stringify({label})}),

  // Force recompute (bulk-sync use; normally unnecessary since every write
  // already triggers one server-side)
  validateSchedule: (c: ApiConfig, projectId: string) => request<{valid:boolean;taskCount:number;dependencyCount:number;cycleTaskIds:string[];cycleTaskNames:string[]}>(c, `/v1/projects/${projectId}/schedule/validate`),

  recompute: (c: ApiConfig, projectId: string) =>
    request<{
      projectId: string;
      taskCount: number;
      criticalTaskCount: number;
      changedTaskCount: number;
      changedTasks: Array<{ taskId:string; taskName:string; startShiftDays:number; finishShiftDays:number; isCritical:boolean; slackDays:number }>;
      computedAt: string;
    }>(c, `/v1/projects/${projectId}/schedule/recompute`, { method: "POST" }),
};

export { ApiError };

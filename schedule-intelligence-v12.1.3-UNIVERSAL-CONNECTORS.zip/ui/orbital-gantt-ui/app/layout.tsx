import "./globals.css";
import { ConnectionProvider } from "@/lib/connection";
import { AuthProvider } from "@/lib/auth";
import { NotificationCenter } from "@/components/NotificationCenter";

export const viewport = { width: "device-width", initialScale: 1, viewportFit: "cover" };

export const metadata = {
  title: "Schedule Intelligence",
  description: "AI-powered scheduling — pure Gantt, beyond thinking.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <AuthProvider><ConnectionProvider>{children}<NotificationCenter /></ConnectionProvider></AuthProvider>
      </body>
    </html>
  );
}

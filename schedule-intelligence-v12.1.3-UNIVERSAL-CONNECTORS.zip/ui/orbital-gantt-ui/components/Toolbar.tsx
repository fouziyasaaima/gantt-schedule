"use client";

import { Plus, Link2, Trash2, Sparkles, RefreshCw } from "lucide-react";

interface Props {
  projectName: string;
  onAddTask: () => void;
  onAddDependency: () => void;
  onDelete: () => void;
  onToggleInsights: () => void;
  onRecompute: () => void;
  deleteDisabled: boolean;
  recomputing: boolean;
}

export function Toolbar({
  projectName,
  onAddTask,
  onAddDependency,
  onDelete,
  onToggleInsights,
  onRecompute,
  deleteDisabled,
  recomputing,
}: Props) {
  return (
    <div className="schedule-toolbar" style={styles.bar}>
      <div style={styles.left}>
        <div style={styles.mark} />
        <span style={styles.projectName}>{projectName}</span>
      </div>
      <div style={styles.actions}>
        <ToolButton icon={<Plus size={14} />} label="Add task" onClick={onAddTask} />
        <ToolButton icon={<Link2 size={14} />} label="Link" onClick={onAddDependency} />
        <ToolButton
          icon={<Trash2 size={14} />}
          label="Delete"
          onClick={onDelete}
          disabled={deleteDisabled}
        />
        <div style={styles.divider} />
        <ToolButton
          icon={<RefreshCw size={14} className={recomputing ? "spin" : undefined} />}
          label="Recompute"
          onClick={onRecompute}
        />
        <ToolButton icon={<Sparkles size={14} />} label="Insights" onClick={onToggleInsights} accent />
      </div>
      <style jsx global>{`
        .spin {
          animation: spin 0.8s linear infinite;
        }
        @keyframes spin {
          to {
            transform: rotate(360deg);
          }
        }
      `}</style>
    </div>
  );
}

function ToolButton({
  icon,
  label,
  onClick,
  disabled,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  disabled?: boolean;
  accent?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        ...styles.button,
        opacity: disabled ? 0.35 : 1,
        cursor: disabled ? "not-allowed" : "pointer",
        color: accent ? "var(--amber)" : "var(--text-dim)",
      }}
      title={label}
    >
      {icon}
      <span style={styles.buttonLabel}>{label}</span>
    </button>
  );
}

const styles: Record<string, React.CSSProperties> = {
  bar: {
    height: 48,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "0 16px",
    borderBottom: "1px solid var(--border)",
    background: "var(--panel)",
    flexShrink: 0,
  },
  left: { display: "flex", alignItems: "center", gap: 10 },
  mark: {
    width: 8,
    height: 8,
    borderRadius: "50%",
    background: "var(--amber)",
    boxShadow: "0 0 8px var(--amber)",
  },
  projectName: { fontSize: 13, fontWeight: 600 },
  actions: { display: "flex", alignItems: "center", gap: 2 },
  divider: { width: 1, height: 20, background: "var(--border)", margin: "0 6px" },
  button: {
    display: "flex",
    alignItems: "center",
    gap: 6,
    background: "none",
    border: "none",
    padding: "7px 10px",
    borderRadius: 4,
    fontSize: 12,
    transition: "background 0.12s var(--ease)",
  },
  buttonLabel: {},
};

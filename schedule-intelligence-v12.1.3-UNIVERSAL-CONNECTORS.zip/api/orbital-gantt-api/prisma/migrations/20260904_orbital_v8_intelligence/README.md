# This migration adds v8 scenario, forecast history and intelligence storage.

# Schedule Intelligence v12.1.3 — Beyond Thinking

Enterprise schedule intelligence with a deterministic Gantt, dependency network, resource intelligence, probabilistic forecast, scenarios, recovery recommendations and organization-scoped Developer API.

## Local-first deployment

The same Docker Compose architecture is intended for Docker Desktop and Linux/DigitalOcean. The browser uses a same-origin `/api` Next.js proxy to the internal API, which keeps HttpOnly sessions reliable across localhost and production.

See `START-HERE.md`, `BUILD-AND-DEPLOY.md` and `SMOKE-TEST.md`.

Product identity shown in the UI: **Schedule Intelligence**.

## Universal Connectors · v12.1

Schedule Intelligence now includes a provider-neutral integration and synchronization layer. A connector can use OAuth 2.0, API key, Bearer token, Basic Auth, custom headers, inbound webhooks, scheduled polling, or explicit user-defined REST operations.

The connector never assumes the external application's schema. Users define the read operations, write operations, field mappings, identity mapping, synchronization direction, target project, and conflict behavior. Write-back is opt-in and requires an explicit POST/PUT/PATCH/DELETE operation plus a successful write validation before it can be used by outbound task synchronization.

For Google Sheets and Microsoft 365/Graph, the connector wizard provides OAuth/base-URL presets. Proprietary systems use the same Generic REST connector. Connector secrets are encrypted with `CONNECTOR_ENCRYPTION_KEY` and are never returned to the browser.
